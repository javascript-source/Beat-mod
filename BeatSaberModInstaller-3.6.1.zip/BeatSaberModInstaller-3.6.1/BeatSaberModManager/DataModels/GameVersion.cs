﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeatSaberModManager.DataModels
{
    public struct GameVersion
    {
        public string value;

        public GameVersion(string _value)
        {
            value = _value;
        }
    }
}
