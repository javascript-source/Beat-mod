﻿public enum Platform
{
    Default,
    Steam,
    Oculus
}
