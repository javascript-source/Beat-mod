# Beat Saber Mod Manager (BeatMods Edition!)

*This is a fork of the Beat Saber Mod Manager by Umbranoxio.*
*It has been adapted to work with https://beatmods.com instead of https://modsaber.org*

This program will install custom mods into Beat Saber automatically, and can be re-run in order to update the mods.

The program currently supports
*  Every approved mod on https://beatmods.com

This uses BeatMods to get the latest approved and manually verified mods latest version automatically.

![Preview](https://cdn.discordapp.com/attachments/456611538912935970/564110534929285122/beatmods-preview.PNG)
